﻿define("epi-ecf-ui/component/Catalogs", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/topic",
    "dojo/dom-class",
    "dojo/string",
// epi shell
    "epi/shell/dgrid/util/misc",
// epi cms
    "epi-cms/widget/HierarchicalList",
    "epi-cms/core/ContentReference",
    "epi-cms/dgrid/formatters",
// commerce
    "./viewmodel/CatalogsViewModel",
// Resources
    "epi/i18n!epi/cms/nls/episerver.shared.header",
    "epi/i18n!epi/cms/nls/commerce.components.catalogs"
],

function (
// dojo
    declare,
    lang,
    on,
    topic,
    domClass,
    dojoString,
// epi shell
    misc,
// epi cms
    HierarchicalList,
    ContentReference,
    formatters,
// commerce
    CatalogsViewModel,
// Resources
    headingResources,
    res
) {
    // module:
    //      epi-ecf-ui.component.Catalogs

    return declare([HierarchicalList], {
        // summary:
        //      Catalogs component.
        // tags:
        //      public

        noThumbnailClass: "epi-dgrid--no-thumbnail",

        catalogListClass: "epi-thumbnailContentList epi-thumbnailContentList--with-icon",

        res: res,

        // To enable context change when search catalog entries
        triggerContextChange: true,

        modelClassName: CatalogsViewModel,

        postMixInProperties: function () {
            this.inherited(arguments);
            lang.mixin(this.modelBindingMap, { showCatalogThumbnails: ["showCatalogThumbnails"] });
        },

        _setShowCatalogThumbnailsAttr: function (value) {
            // summary: 
            //      Set show catalog thumbnails attribute.
            // tags:
            //      protected

            var gridNode = this.list.grid.domNode;

            domClass.toggle(gridNode, this.catalogListClass);

            if (!this.model.showCatalogThumbnails) {
                domClass.add(gridNode, this.noThumbnailClass);
            } else {
                domClass.remove(gridNode, this.noThumbnailClass);
            }
        },

        getThumbnailSelector: function (item) {
            // summary: 
            //      Get thumbnail url from content item.
            // tags:
            //      public

            if (item && item.properties) {
                return item.properties.thumbnail;
            }
            return '';
        },

        getTitleSelector: function (item) {
            // summary: 
            //      Get title information from content item.
            // tags:
            //      public

            if (item) {
                var reference = new ContentReference(item.contentLink);
                if (reference) {
                    return dojoString.substitute("${name}, ${resourceId}: ${id} (${resourceType}: ${type})",
                        { name: item.name, resourceId: headingResources.id, id: reference.id, resourceType: headingResources.type, type: item.contentTypeName });
                }
            }
            return '';
        },

        _setFormatterForList: function () {
            // summary: 
            //      Reset formatter for catalog hierarchical list.
            // tags:
            //      protected

            var grid = this.list.grid;
            // Reset formatter for catalog list to display both thumbnail and icon type identifier
            grid.formatters = [lang.hitch(this, this.catalogItemFormatter)];
            grid.configStructure();
        },

        catalogItemFormatter: function (value, object, node, options) {
            // summary: 
            //      Formatter for catalog list to display both thumbnail and icon type identifier.
            // tags:
            //      public

            var text = misc.htmlEncode(object.name);
            var title = misc.attributeEncode(this.getTitleSelector(object) || text);
            var returnValue = dojoString.substitute("${thumbnail} ${icon} ${text}", {
                thumbnail: formatters.thumbnail(this.getThumbnailSelector(object)),
                icon: formatters.contentIcon(object.typeIdentifier),
                text: misc.ellipsis(text, title)
            });

            node.innerHTML = returnValue;
            return returnValue;
        },

        startup: function () {
            // summary: 
            //      Adds the breadcrumb widget to the top of the list widget.
            // tags:
            //      protected
            this.inherited(arguments);

            topic.subscribe("relationChanged", lang.hitch(this, function () {
                this.list._updateQuery(this.list.query);
            }));
            // disable DnD action on this gadget
            this.tree.dndController.readOnly = true;

            this._setFormatterForList();
        },

        postCreate: function () {
            this.inherited(arguments);

            this.list.set("noDataMessage", this.res.nocatalogentry);
        },

        setupContextMenu: function () {
            // summary: set up the context menu. Overrriden to not add context menu on the catalog tree gadget
            //      
            // tag:
            //      public override

        }
    });
});