﻿define("epi-ecf-ui/contentediting/editors/model/CommerceMediaCollectionEditorModel", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    // epi
    "epi/shell/command/DelegateCommand",
    "epi-cms/contentediting/editors/model/CollectionEditorModel",
    "epi-cms/dgrid/formatters",
    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.commercemediacollectioneditor"
], function (
    array,
    declare,
    lang,
    Deferred,
     // epi
    DelegateCommand,
    CollectionEditorModel,
    formatters,
    // Resources
    res
) {
    return declare([CollectionEditorModel], {

        addItem: function (item, refItem, before) {
            // summary:
            //      Add new item.
            // item: Object
            //      The item raw data
            // refItem: Object
            //      The reference item (item model instance)
            // before: Boolean
            //      Indicates that the new item should be added before the reference item.
            // tags:
            //      public override

            var items = this.get("items");
            if (!items || items.length < 1) {
                return this.inherited(arguments);
            }

            // check if adding item is existed, to move it to top
            // instead of adding duplicated item.
            var itemIdentifier = item.permanentUrl || item.assetKey;
            var existingItem;
            array.some(items, function (oldItem) {
                if (oldItem && oldItem.assetKey === itemIdentifier) {
                    existingItem = oldItem;
                    return true;
                }
            });
            if (existingItem) {
                var def = new Deferred();
                this.moveItem(existingItem, refItem || existingItem, before || true);
                def.resolve();
                return def;
            } else {
                return this.inherited(arguments);
            }
        },

        saveItem: function (item, index) {
            // summary:
            //      Save an item.
            // item: Object
            //      The item raw data
            // index: Number
            //      The item index
            // tags:
            //      public override

            var items = this.get("items");
            if (!items || items.length < 1) {
                return this.inherited(arguments);
            }

            // Don't save if there already is an item with this key.
            var itemExists;
            var currentIndex = 0;
            var itemIdentifier = item.permanentUrl || item.assetKey;
            array.some(items, function (oldItem) {
                if (oldItem && oldItem.assetKey === itemIdentifier && currentIndex !== index) {
                    itemExists = true;
                    return true;
                }
                currentIndex++;
            });

            if (!itemExists) {
                return this.inherited(arguments);
            }
        },

        getListCommands: function (availableCommands) {
            // summary:
            //      get list commands from avaible commands
            // tags:
            //      public override
            return [
                new DelegateCommand({
                    name: "add",
                    label: res.addlabel,
                    iconClass: "epi-iconPlus",
                    canExecute: true,
                    isAvailable: true,
                    delegate: lang.hitch(this, this.addItemDelegate)
                })
            ];
        },

        generateFormatters: function (columnDefinitions) {
            // summary:
            //      Generate formatters for the specified column definitions.
            // columnDefinitions:
            //      The definition for the columns that should get the generated formatters.
            // tags:
            //      public override

            var thumbnailFormatter = function (value) {
                return [formatters.thumbnail(value)];
            };

            for (var columnName in columnDefinitions) {
                if (columnDefinitions[columnName].isThumbnail) {
                    columnDefinitions[columnName].formatter = thumbnailFormatter;

                    break;
                }
            }
            
            return columnDefinitions;
        }
    });
});