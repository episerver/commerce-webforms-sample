﻿define("epi-ecf-ui/contentediting/editors/AssociationCollectionEditor", [
// dojo
     "dojo/_base/array",
    "dojo/aspect",
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/dom-construct",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/when",
    "dojo/topic",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",

// dgrid
    "dgrid/editor",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",

// epi
    "epi/shell/_ContextMixin",
    "epi/shell/dgrid/_EditorMetadataMixin",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/command/builder/ButtonBuilder",
    "epi/shell/widget/dialog/Confirmation",
    "epi/dependency",
    "epi/string",

// epi cms
    "epi-cms/contentediting/editors/_AddItemDialogMixin",
    "epi-cms/core/ContentReference",
    "epi-cms/widget/ContentSelectorDialog",
    "epi-cms/dgrid/formatters",
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/dgrid/DnD",

// epi ecf
    "../viewmodel/AssociationCollectionEditorModel",
    "../../store/CompositeKey",
    "./LinkEditEditor",
    "./_CollectionEditorDndMixin",
     "../../dgrid/_ClickablePathColumnMixin",
    "../ModelSupport",

// resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.associationcollectioneditor",
    "epi/i18n!epi/nls/episerver.shared"
],
function (
// dojo
    array,
    aspect,
    declare,
    Deferred,
    domConstruct,
    lang,
    Stateful,
    when,
    topic,

// dijit
    _TemplatedMixin,
    _Widget,

// dgrid
    editor,
    Grid,
    Selection,

// epi
    _ContextMixin,
    _EditorMetadataMixin,
    _FocusableMixin,
    _ModelBindingMixin,
    ButtonBuilder,
    Confirmation,
    dependency,
    epiString,

// epi cms
    _AddItemDialogMixin,
    ContentReference,
    ContentSelectorDialog,
    formatters,
    WithContextMenu,
    DnD,

// epi ecf
    AssociationCollectionEditorModel,
    CompositeKey,
    LinkEditEditor,
    _CollectionEditorDndMixin,
    _ClickablePathColumnMixin,
    ModelSupport,

// resources
    resources,
    sharedResources

) {
    var collectionEditor = declare([_Widget, _TemplatedMixin, _ModelBindingMixin, _AddItemDialogMixin, _FocusableMixin, _CollectionEditorDndMixin, _ContextMixin], {

        /*jshint multistr: true */
        templateString: '<div>\
                            <div data-dojo-attach-point="commandTargetNode"></div>\
                            <div data-dojo-attach-point="overlayDnd">\
                                <div class="epi-associationCollectionEditor" data-dojo-attach-point="gridNode"></div>\
                            </div>\
                        </div>',

        grid: null,

        gridOverlayClass: "epi-grid-dnd-overlay",

        modelType: AssociationCollectionEditorModel,

        itemType: "EPiServer.Commerce.Shell.Rest.Models.AssociationModel",

        allowedDndTypes: [ModelSupport.contentTypeIdentifier.entryContentBase, ModelSupport.linkTypeIdentifier.association],

        includedColumns: ["ContentTypeIdentifier", "Name", "Code", "Path", "GroupName"],

        editableColumns: ["GroupName"],

        // Grid action column name
        cellActionName: "epiGridAction",

        itemEditorType: ContentSelectorDialog,

        postMixInProperties: function () {
            this.model = this.model || new this.modelType({
                itemType: this.itemType
            });
        },

        postCreate: function () {
            this.inherited(arguments);

            if (!this.roots) {
                var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors"),
                    settings = contentRepositoryDescriptors.catalog;
                this.roots = settings.roots;
            }
            var builder = new ButtonBuilder({ settings: { showLabel: true } }),
                command = this.model.getListCommand();
            builder.create(command, this.commandTargetNode);

            // Set up metadata capable grid type
            var EditorGrid = declare([Grid, Selection, editor, _EditorMetadataMixin, WithContextMenu, DnD, _ClickablePathColumnMixin], {});

            // Get metadata for itemType
            when(this.model.metadataManager.getMetadataForType(this.itemType), lang.hitch(this, function (metadata) {
                // Set up columns object with one column for context menu
                var columns = [
                    {
                        field: "contentTypeIdentifier",
                        renderHeaderCell: function () { }, // no header
                        get: function (object) {
                            return object.contentTypeIdentifier;
                        },
                        label: "",
                        formatter: formatters.contentIcon,
                        className: "epi-columnIcon16x16",
                        sortable: false
                    },
                    {
                        field: this.cellActionName,
                        renderHeaderCell: function () { }, // no header
                        renderCell: lang.hitch(this, function (object, value, node, options) {

                                  var builder = new ButtonBuilder({ settings: { showLabel: false } }),
                                    commands = this.model.getCommands(this.grid, null);

                                  array.forEach(commands, function (command) {
                                      builder.create(command, node);
                                  });
                    }),
                        className: "epi-columnNarrow",
                        sortable: false
                    }],
                    // Prepare store capable of doing remove/re-add on changes that affect composite keys
                    compositeKeyProperties = ["groupName", "type"],
                    ckStore = new CompositeKey(dependency.resolve("epi.storeregistry").get("epi.commerce.association"), compositeKeyProperties, true),
                    // Create grid
                    grid = this.grid = new EditorGrid({
                        store: ckStore,
                        minWidth: 100,
                        noDataMessage: resources.nodatamessage,
                        selectionMode: "single",
                        "class": "epi-plain-grid epi-plain-grid-modal epi-plain-grid--margin-bottom epi-plain-grid--cell-borders",
                        columns: columns,
                        metadata: {
                            properties: metadata.properties,
                            gridIncluded: this.includedColumns,
                            gridEditable: this.editableColumns
                        },
                        dndSourceTypes: [ModelSupport.linkTypeIdentifier.association],
                        dndParams: {
                            copyOnly: true,
                            accept: this.allowedDndTypes || [],
                            creator: lang.hitch(this, this._dndNodeCreator)
                        }
                    });
                domConstruct.place(this.grid.domNode, this.gridNode);
                this.own(grid,
                    // Since grid will not be able to update the row due to the changed Id, we force a refresh
                    aspect.after(ckStore, "removeReAdd", function (promise) {
                        when(promise, function () {
                            grid.refresh();
                        });
                    }),
                    // Refresh grid when model has changed
                    this.model.on("itemAdded", lang.hitch(this, function () {
                        this.grid.refresh();
                    })),
                    this.model.on("itemSaved", lang.hitch(this, function () {
                        this.grid.refresh();
                    })),
                    this.model.on("itemRemoved", lang.hitch(this, function () {
                        this.grid.refresh();
                    })),
                    // Set query depending on contentLink property on model
                    this.model.watch("contentLink", lang.hitch(this, function (property, oldValue, newValue) {
                        if (oldValue !== newValue) {
                            this._updateGridQuery(newValue);
                            grid.resize();
                        }
                    })),
                    // Listen to remove command event
                    this.model.on("removeCommandEvent", lang.hitch(this, function () {
                        // Show confirmation dialog to confirm delete price item
                        when(this._showConfirmation(resources.deleteconfirmation.title, resources.deleteconfirmation.description), lang.hitch(this, function () {
                            if (this.model) {
                                var remove = [];
                                for (var selected in this.grid.selection) {
                                    if (this.grid.selection.hasOwnProperty(selected)) {
                                        remove.push(this.model.store.get(selected));
                                    }
                                }
                                return this.model.removeItems(remove);
                            }
                        }));
                    }))
                );

                this._setupDnD();
                when(this.getCurrentContext(), lang.hitch(this, function (currentContext) {
                    this._updateGridQuery(currentContext.id);
                    this.grid.startup();
                }));
            }));

        },

        _updateGridQuery: function(value){
            this.grid.set("query", { referenceId: new ContentReference(value).createVersionUnspecificReference().toString() });
        },

        _addItem: function (item) {
            when(this._dndGetItemData(item), lang.hitch(this, function (itemData) {
                if (itemData) {
                    return this.model.addItem(itemData);
                }
            }));
        },

        _noDataMessage: resources.nodatamessage,

         resize: function () {
             this.inherited(arguments);

             if (this.grid) {
                 this.grid.resize();
             }
         },

        _getDialogTitleText: function() {
            return resources.addlabel;
        },

        _createItemEditor: function() {
            return new this.itemEditorType({
                canSelectOwnerContent: false,
                showButtons: false,
                roots: this.roots,
                allowedTypes: [ModelSupport.contentTypeIdentifier.entryContentBase],
                showAllLanguages: false
            });
        },

        _dndGetItemData: function (item) {
            return when(item.data, lang.hitch(this, function (data) {
                if (data) {
                    return this._createItem(data.contentLink, data.name);
                }
            }));
        },

        _createItem: function (targetLink, name) {
            return {
                name: name || targetLink,
                sortOrder: 0,
                source: this.model.get("contentLink"),
                target: targetLink
            };
        },

        onExecuteDialog: function () {
            var item = this._itemEditor.get("value");
            this._addItem({ data: { contentLink: item } }, true);
        },

        _setValueAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this._set("value", value);

            if (this.model) {
                this.model.set("contentLink", value);
            }
        },

        destroy: function () {
            // summary:
            //		Destroy the object.

            if (this.grid) {
                this.grid.destroy();
                this.grid = null;
            }

            this.inherited(arguments);
        },

        _showConfirmation: function (title, description) {
            // summary:
            //      Wrap epi.shell.widget.dialog.Confirmation for short type
            //      and return deferred object
            // description:
            //      String: Text to display on dialog
            // tags:
            //      private

            var deferred = new Deferred();

            var dialog = new Confirmation({
                destroyOnHide: true,
                title: epiString.toHTML(title),
                description: epiString.toHTML(description),
                onAction: function (confirmed) {
                    if (confirmed) {
                        deferred.resolve();
                    } else {
                        deferred.cancel();
                    }
                }
            });
            dialog.show();

            return deferred.promise;
        }
    });

    return declare([LinkEditEditor], {

        resources: resources,

        gridCollectionType: collectionEditor,

        executeAction: function (actionName) {
            // summary:
            //      Called when [Related entries] link clicked
            // tags:
            //      public override

            topic.publish("/epi/layout/pinnable/tools/toggle", true);
        }
    });

});
