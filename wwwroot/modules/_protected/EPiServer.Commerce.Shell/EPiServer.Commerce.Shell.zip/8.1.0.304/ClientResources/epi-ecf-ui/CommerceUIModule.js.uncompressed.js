﻿define("epi-ecf-ui/CommerceUIModule", [
    "dojo/_base/declare",
    "epi/_Module",
    "epi/routes",
    "epi/dependency",
    "epi/shell/store/Registry",
    "epi/shell/ClipboardManager",
    "epi-cms/store/CustomQueryEngine"
], function (
    declare,
    _Module,
    routes,
    dependency,
    Registry,
    ClipboardManager,
    CustomQueryEngine
) {

    return declare([_Module], {
        // summary: this is the initializer of CommerceUIModule.

        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //		Initialize module
            //
            // description:
            //

            this.inherited(arguments);

            // Initialize stores
            this._initializeStores();


            // Initialize global/singleton instance
            this._initializeGlobalInstances();
        },

        _initializeStores: function () {
            var registry = this.resolveDependency("epi.storeregistry");
            registry.create("epi.commerce.market", this._getRestPath("market"), {});
            registry.create("epi.commerce.price", this._getRestPath("price"), {queryEngine: CustomQueryEngine});
            registry.create("epi.commerce.inventory", this._getRestPath("inventory"), {});
            registry.create("epi.commerce.relation", this._getRestPath("relation"), { queryEngine: CustomQueryEngine });
            registry.create("epi.commerce.association", this._getRestPath("association"), { queryEngine: CustomQueryEngine });
            registry.create("epi.commerce.customergroup", this._getRestPath("customergroup"), {});
            registry.create("epi.commerce.associationgroupdefinition", this._getRestPath("associationgroupdefinition"), {});
            registry.create("epi.commerce.relationgroupdefinition", this._getRestPath("relationgroupdefinition"), {});
            registry.create("epi.commerce.metadictionary", this._getRestPath("metadictionary"), {});
            registry.create("epi.commerce.metadictionaryitem", this._getRestPath("metadictionaryitem"), {});
        },

        _getRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "EPiServer.Commerce.Shell", storeName: name });
        },

        _initializeGlobalInstances: function () {
            var registry = new Registry();
            registry.add("epi.commerce.global.clipboard", new ClipboardManager());
            dependency.register("epi.commerce.global", registry);
        }
    });
});
