﻿define("epi-ecf-ui/component/viewmodel/CatalogsViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi-cms/widget/viewmodel/HierarchicalListViewModel",
// Commerce
    "epi-ecf-ui/widget/viewmodel/CatalogTreeStoreModel",
    "epi-ecf-ui/command/ShowCatalogThumbnails"
],

function (
// dojo
    declare,
    lang,
    when,
// epi
    HierarchicalListViewModel,
// Commerce
    CatalogTreeStoreModel,
    ShowCatalogThumbnailsCommand
) {
    // module:
    //      epi-ecf-ui.component.viewmodel.CatalogsViewModel

    return declare([HierarchicalListViewModel], {
        // summary:
        //      Catalogs view model.
        // tags:
        //      public

        treeStoreModelClass: CatalogTreeStoreModel,

        // showCatalogThumbnails: [public] Boolean
        //      Flag which indicates whether to show thumbnails in catalog hierarchical list. Value is true if thumbnails should be shown; otherwise false.
        showCatalogThumbnails: true,

        postscript: function () {
            /*jslint bitwise: true*/
            this.isAvailableFlags = this.isAvailableFlags || this.menuType.ROOT | this.menuType.TREE | this.menuType.LIST;

            this.inherited(arguments);

            this.set("commands", [new ShowCatalogThumbnailsCommand({ model: this })]);
        },

        _showCatalogThumbnailsSetter: function (value) {
            // summary:
            //      Set the show catalog thumbnails property.
            // tags:
            //      protected

            this.showCatalogThumbnails = value;
        },

        _getSortSettings: function () {
            // summary:
            //      Returns the list of sort criteria.
            // tags:
            //      protected override

            // overwrite to return empty sort setting, which means that the default content's sort order will be used.
            return [];
        },

        contentContextChanged: function (context, callerData) {
            // summary:
            //      Called when the currently loaded content changes. I.e. a new content data object is loaded into the preview area.
            //      Override _ContextContextMixin.contentContextChanged
            // tags:
            //      protected override

            // If the list already has a context, don't change it
            var oldListRef = this.get("currentListItem");
            if (oldListRef) {
                return;
            }

            // If not, let the base implementation set up the initial context
            this.inherited(arguments);
        },

        _listQuerySetter: function(value){
            // summary:
            //      Custom setter for the list query to create a different query depending
            //      on if the item supports sorting of children.
            // tags:
            //      private

            if (!value){
                this.listQuery = value;
                return;
            }

            return when(this.store.get(value.referenceId), lang.hitch(this, function(item){
                var supportSorting = !!item && !!item.capabilities && !!item.capabilities.sortChildren;
                lang.mixin(value, {
                    simplified: !supportSorting
                });
                this.listQuery = value;
            }));
        }
    });
});