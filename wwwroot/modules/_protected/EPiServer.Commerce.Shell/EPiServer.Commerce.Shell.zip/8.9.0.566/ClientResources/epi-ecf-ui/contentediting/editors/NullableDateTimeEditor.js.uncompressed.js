require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/NullableDateTimeEditor.html':"﻿<div class=\"dijitInline dijitInputContainer\">\n    <div data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\" data-dojo-attach-point=\"dateSelector\"></div\n    ><div data-dojo-type=\"dijit/form/Button\" class=\"epi-chromelessButton epi-visibleLink\" style=\"padding-left:10px\" data-dojo-attach-point=\"clearValueLink\" data-dojo-attach-event=\"onClick:_clearValueClick\">${resources.removebutton}</div>\n    <div><span class=\"epi-secondaryText\">${resources.helptext}</span></div>\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/NullableDateTimeEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/on",
    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Button",
    // epi
    "epi/shell/layout/_LayoutWidget",
    "epi/shell/widget/_ValueRequiredMixin",
    "epi/shell/widget/DateTimeSelectorDropDown",
    // template
    "dojo/text!./templates/NullableDateTimeEditor.html",
    // resources
    "epi/i18n!epi/cms/nls/commerce.widget.nullabledatetime"
],
function (
    // dojo
    declare,
    lang,
    domStyle,
    on,
    // dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    Button,
    // epi
    _LayoutWidget,
    _ValueRequiredMixin,
    DateTimeSelectorDropDown,
    // template
    template,
    // resources
    resources
    ) {

    return declare([_LayoutWidget, _Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ValueRequiredMixin], {

        templateString: template,
        resources: resources,

        value: null,

        constraints: {
            min: '1753-01-01'
        },

        rangeMessage: "",

        postCreate: function () {
            this.inherited(arguments);

            //Set constraints to date time selector
            this.dateSelector.set("constraints", this.constraints);

            this.own(
                this.dateSelector.on("change", lang.hitch(this, function(value){
                    this._set("value", value);
                    this.onChange(value);
                }))
            );
        },

        onChange: function(value){
            if (!this.disabled){
                this.validate();
            }
            this._showClearLink(!!value);
        },

        _showClearLink: function(show){
            domStyle.set(this.clearValueLink.domNode, "display", show ? "" : "none");
        },

        isValid: function () {
            return this.dateSelector.isValid();
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.
            // value: DateTimeRange
            //      The range of time to display.
            this._set("value", value);
            this.dateSelector.set("value", value);
            this.onChange(value);
        },

        _setConstraintsAttr: function (constraints){
            this._set("constraints", constraints);
            this.dateSelector.set("constraints", constraints);
        },

        _setRangeMessageAttr: function(rangeMessage){
            this._set("rangeMessage", rangeMessage);
            this.dateSelector.set("rangeMessage", rangeMessage);
        },

        _getValueAttr: function () {
            return this.dateSelector.get("value");
        },

        _clearValueClick: function (){
            this.set("value", null);
        }
    });
});
