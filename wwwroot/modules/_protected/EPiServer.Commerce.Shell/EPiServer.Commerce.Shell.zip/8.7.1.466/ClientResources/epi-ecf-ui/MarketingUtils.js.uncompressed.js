define("epi-ecf-ui/MarketingUtils", [
],

function (
) {
    var marketingUtils = {
        // summary:
        //    This class contains utilities for working with marketing objects
        //    (campaigns, promotions)
        // tags:
        //    public static
        
        // status: Object
        //      Statuses used on marketing objects 
        status : {
            // Note: These should match EPiServer.Commerce.Shell.Rest.Models.CampaignItemStatus
            notSet: 0,
            active: 1,
            pending : 2,
            expired: 3,
            suspended: 4,
            inactive: 5,
            deleted: 6
        },

        // contentTypeIdentifier: Object
        //      Type identifiers for marketing content types
        contentTypeIdentifier: {
            salesCampaign: "episerver.commerce.marketing.salescampaign",
            promotionData: "episerver.commerce.marketing.promotiondata",
            orderPromotion:"episerver.commerce.marketing.orderpromotion",
            entryPromotion: "episerver.commerce.marketing.entrypromotion",
            shippingPromotion: "episerver.commerce.marketing.shippingpromotion"
        }
    };

    return marketingUtils;
});