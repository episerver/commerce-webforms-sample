define(
"dojo/cldr/nls/zh-hk/number", //begin v1.x content
{
	"currencyFormat": "¤#,##0.00",
	"decimalFormat-short": "000T",
	"nan": "非數值"
}
//end v1.x content
);