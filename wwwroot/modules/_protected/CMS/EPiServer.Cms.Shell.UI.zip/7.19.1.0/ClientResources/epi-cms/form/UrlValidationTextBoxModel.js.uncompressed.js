﻿define("epi-cms/form/UrlValidationTextBoxModel", [
    "dojo/_base/declare",
    "dojo/_base/lang",
     "epi/Url"
], function (
    declare,
    lang, 
    Url
    ) {

    return declare([], {
        // summary:
        //    Represents model for Url validation textbox.
        // tags:
        //    internal

        validator: function (value, flags) {
            // summary:
            //		Checks if a string could be a valid URL
            // value: String

            var re = new RegExp("^(https://?|http://|ftp://|file://|\\\\).+$", "i");
            return re.test(value);
        },

        validateUrl: function (value) {

            // trim the spaces
            value = value ? lang.trim(value) : '';
            if (value === '') {
                return value;
            }
            
            // make sure the hyper link has scheme. Default is http.
            var fileSchemaPrefix = "file://";

            var url = new Url(value);
            if (value.indexOf("//") === 0) {
                value = fileSchemaPrefix + value.substr(value.indexOf("//") + 2);
            } else if (value.indexOf("\\\\") === 0) {
                value = fileSchemaPrefix + value.substr(value.indexOf("\\\\") + 2);
            } else if (!(url.scheme)) {
                
                // in case no scheme is given then assume its http
                value = "http://" + value;
            }
            
            return value;
        }
    });
});